import SwiftUI
import UIKit
import AVFoundation

struct CameraPreview: UIViewRepresentable {
    
    // MARK: Properties
    
    // View Model
    @EnvironmentObject var cameraModel : CameraViewModel
    
    // Custom Size of Camera Preview
    var size: CGSize
    
    // MARK: Functions
    
    func makeUIView(context: Context) ->  UIView {
        
        // Camera Preview View
        let view = UIView()
        
        cameraModel.preview = AVCaptureVideoPreviewLayer(session: cameraModel.session)
        cameraModel.preview.frame.size = size
        
        cameraModel.preview.videoGravity = .resizeAspectFill
        
        view.layer.addSublayer(cameraModel.preview)
        cameraModel.session.startRunning()
    
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {
        
        // Adjusting camera preview based on the device's current orientation.
        cameraModel.preview.frame.size =  size
        if cameraModel.preview.connection?.isVideoOrientationSupported == true {
            cameraModel.preview.connection?.videoOrientation = AVCaptureVideoOrientation(rawValue:  UIDevice.current.orientation.rawValue)!
        }
    }
    
}
