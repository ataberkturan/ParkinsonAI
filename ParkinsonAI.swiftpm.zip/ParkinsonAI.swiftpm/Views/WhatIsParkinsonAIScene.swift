import SwiftUI

struct WhatIsParkinsonAIScene: View {
    
    // MARK: Properties
    
    // Controlling the page navigation.
    @State var nextPage: Bool = false
    
    // MARK: Animation Properties
    @State var backgroundOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    
    // MARK: View
    
    var body: some View {
        VStack {
            Spacer()
            HStack(spacing: 15) {
                
                // The informational text which is appears on the right side of the screen.
                InfoTextView(subtitle: "What is", subtitleColor: .indigo, title: "ParkinsonAI", titleSize: 50, bodyIsOn: true, bodyText: "ParkinsonAI is a machine-learning-based app that can diagnose Parkinson’s disease in 3 different tests. The first test is the hand tremor test to detect rhythmic shaking of muscles. The second test is a speaking test to detect muscle control in the throat and chest. The last and third test is a handwriting test to detect trembling handwriting.", bodyTextColor: .white, bodyTextSize: 20, bodyPaddingTop: 30, bodyWidth: 500)
                .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                                .fill(Color(.systemGray5))
                                .frame(width: 585, height: 550)
                                .clipped(), alignment: .center)
                
                // Card View
                VStack(spacing: 58) {
                    
                    // Hand Termor Test Card
                    CardView(cardSymbolIsOn: true, cardSymbolName: "hand.wave.fill", cardSymbolSize: 40, cardSymbolColor: .white, cardSymbolWidth: 173, cardSymbolHeight: 100, cardSubtitleIsOn: true, cardSubtitle: "Step 1", cardSubtitleSize: 10, cardSubtitleColor: .orange, cardTitle: "Hand Tremor Test", cardTitleSize: 13, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.6, width: 173, height: 173, cornerRadius: 47, backgroundColor: Color(.systemGray5))
                    
                    // Speaking Test Card
                    CardView(cardSymbolIsOn: true, cardSymbolName: "waveform", cardSymbolSize: 40, cardSymbolColor: .white, cardSymbolWidth: 173, cardSymbolHeight: 100, cardSubtitleIsOn: true, cardSubtitle: "Step 2", cardSubtitleSize: 10, cardSubtitleColor: .orange, cardTitle: "Speaking Test", cardTitleSize: 13, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.7, width: 173, height: 173, cornerRadius: 47, backgroundColor: Color(.systemGray5))
                    
                    // Handwriting Test Card
                    CardView(cardSymbolIsOn: true, cardSymbolName: "pencil.and.outline", cardSymbolSize: 40, cardSymbolColor: .white, cardSymbolWidth: 173, cardSymbolHeight: 100, cardSubtitleIsOn: true, cardSubtitle: "Step 3", cardSubtitleSize: 10, cardSubtitleColor: .orange, cardTitle: "Handwriting Test", cardTitleSize: 13, cardTitleColor: .white, paddingTop: 0, animationDuration: 0.8, width: 173, height: 173, cornerRadius: 47, backgroundColor: Color(.systemGray5))
                }
                .padding(.leading, 42)
            }
            .background(Group {
                EmptyView()
            }, alignment: .center)
            .frame(width: 900, height: 550, alignment: .center)
            .clipped()
            .cornerRadius(47)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0) { 
                backgroundOpacity = 1.0
            }
            
            Spacer()
            
            // Navigation button
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Let's Start") { 
                    withAnimation { 
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .purple))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 1) { 
                navigationButtonOpacity = 1.0
            }
            
        }
        .navigationStack()
        .overlay(nextPage ? RequiredQuestionScene() : nil)
    }
    
}
