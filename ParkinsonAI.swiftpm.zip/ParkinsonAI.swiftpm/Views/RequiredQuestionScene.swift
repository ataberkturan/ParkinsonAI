import SwiftUI

struct RequiredQuestionScene: View {
    
    // MARK: Properties
    
    // Controlling the page navigation.
    @State var nextPage: Bool = false
    
    // Yes/No button selected status.
    @State var yesButtonSelected = false
    @State var noButtonSelected = false
    
    // Control variable of Navigation Button's disabled function.
    @State var navigationButtonIsActive = false
    
    // MARK: Animation Properties
    @State var backgroundOpacity = 0.0
    @State var yesButtonOpacity = 0.0
    @State var noButtonOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    
    // MARK: View
    
    var body: some View {
        VStack {
            
            Spacer()
            
            VStack {
                
                // The informational text which is appears on the top of the screen.
                InfoTextView(subtitle: "Required Question", subtitleColor: .purple, title: "Did you take any caffeine or medicine" + "\n" + "today?", titleSize: 30, bodyIsOn: false, bodyText: "", bodyTextColor: .white, bodyTextSize: 0, bodyPaddingTop: 0, bodyWidth: 0)
                .padding(.top, 40)
                
                // Answer Buttons  
                VStack(alignment: .center, spacing: 20) {
                    
                    // "Yes, I did" Button
                    Button { 
                        OverallScoreCalculator.shared.requiredQuestionAnswer = true
                        navigationButtonIsActive = true
                        noButtonSelected = false
                        yesButtonSelected = true
                    } label : {
                        HStack {
                            Spacer()
                            Text("Yes, I did")
                                .font(.system(size: 20, weight: .bold, design: .default))
                                .foregroundColor(.white)
                            Spacer()
                        }
                    }
                    .frame(width: 600, height: 60, alignment: .center)
                    .background(Color(.systemGray2))
                    .cornerRadius(47)
                    .overlay(
                        RoundedRectangle(cornerRadius: 47)
                            .stroke(Color.white, lineWidth: yesButtonSelected ? 3 : 0)
                    )
                    .opacity(yesButtonOpacity)
                    .basicEaseIn(delayCount: 0.6, {
                        yesButtonOpacity = 1.0
                    })
                    
                    // "No, I didn't" Button
                    Button { 
                        OverallScoreCalculator.shared.requiredQuestionAnswer = false
                        navigationButtonIsActive = true
                        noButtonSelected = true
                        yesButtonSelected = false
                    } label : {
                        HStack {
                            Spacer()
                            Text("No, I didn't")
                                .font(.system(size: 20, weight: .bold, design: .default))
                                .foregroundColor(.white)
                            Spacer()
                        }
                    }
                    .frame(width: 600, height: 60, alignment: .center)
                    .background(Color.purple)
                    .cornerRadius(47)
                    .overlay(
                        RoundedRectangle(cornerRadius: 47)
                            .stroke(Color.white, lineWidth: noButtonSelected ? 3 : 0)
                    )
                    .opacity(noButtonOpacity)
                    .basicEaseIn(delayCount: 0.8, {
                        noButtonOpacity = 1.0
                    })
                }
                .padding(.bottom, 40)
            }
            .padding(.horizontal, 40)
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                            .fill(Color(.systemGray5)), alignment: .center)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0, {
                backgroundOpacity = 1.0
            })
            
            Spacer()
            
            // Navigation Button
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Next") { 
                    withAnimation { 
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: Color(.systemGray5)))
                .disabled(
                    navigationButtonIsActive ? false : true
                )
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonIsActive ?
                navigationButtonOpacity : 0.5)
            .basicEaseIn(delayCount: 1) {
                navigationButtonOpacity = 1.0
            }
        }
        .navigationStack() 
        .overlay(nextPage ? HandTremorTestScene() : nil)
    }
    
}
