import SwiftUI

struct WhatIsParkinsonScene: View {
    
    // MARK: Properties
    
    // Controlling the page navigation.
    @State var nextPage: Bool = false
    
    // MARK: Animation Properties
    @State var backgroundOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    
    // MARK: View
    
    var body: some View {
        VStack {
            Spacer()
            HStack(spacing: 98) {
                
                // The informational text which is appears on the center of the screen.
                InfoTextView(subtitle: "What is", subtitleColor: .blue, title: "Parkinson?", titleSize: 50, bodyIsOn: true, bodyText: "Parkinson's disease is a long-term degenerative disorder of the central nervous system that mainly affects the motor system. The symptoms usually emerge slowly, and as the disease worsens, non-motor symptoms become more common. The most obvious early symptoms are tremors, rigidity, slowness of movement, and difficulty with walking.", bodyTextColor: .white, bodyTextSize: 20, bodyPaddingTop: 30, bodyWidth: 500)
                .offset(x: -30, y: 0)
            
                // The brain symbol with blue background is assigned to the right side of the screen.
                VStack(alignment: .trailing) {
                    Image(systemName: "brain.head.profile")
                        .font(.system(size: 120, weight: .bold, design: .default))
                }
                .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                    .fill(Color.blue)
                    .frame(width: 300, height: 550, alignment: .trailing)
                    .clipped(), alignment: .center)
            }
            .background(RoundedRectangle(cornerRadius: 47, style: .continuous)
                .fill(Color(.systemGray5))
                .frame(width: 900, height: 550)
                .clipped(), alignment: .center)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0) { 
                backgroundOpacity = 1.0
            }
        
            Spacer()
            
            // Navigation Button
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Next") { 
                    withAnimation { 
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: Color(.systemGray5)))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 0.6) { 
                navigationButtonOpacity = 1.0
            }
        }
        .navigationStack()
        .overlay(nextPage ? WhatIsParkinsonAIScene() : nil)
    }
    
}
