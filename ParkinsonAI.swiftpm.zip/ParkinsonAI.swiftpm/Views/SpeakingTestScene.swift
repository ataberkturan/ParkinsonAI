import SwiftUI

struct SpeakingTestScene: View {
    
    // MARK: Properties
    
    // AudioRecorder Observed Object
    @ObservedObject var audioRecorder: AudioRecorder
    
    // Controlling the page navigation.
    @State var nextPage = false
    
    // Control variable of Navigation Button's disabled function.
    @State var navigationButtonIsActive = false
    
    // Progress View status
    @State var showProgressView = false
    
    // MARK: Animation Properties
    @State var backgroundOpacity = 0.0
    @State var guidingTextOpacity = 0.0
    @State var recordButtonOpacity = 0.0
    @State var infoTextOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    
    // MARK: View
    
    var body: some View {
        ZStack {
            VStack {
                
                Spacer()
                
                VStack(spacing: 40) {
                    
                    // The informational text which is appears on the top of the screen.
                    InfoTextView(subtitle: "Speaking Test", subtitleColor: .purple, title: "Make yourself comfortable, and start recording.", titleSize: 35, bodyIsOn: true, bodyText: "When you feel ready, press the microphone button, and please say the exact words given below.", bodyTextColor: .secondary, bodyTextSize: 20, bodyPaddingTop: 20, bodyWidth: 800)
                    
                    // Speaking Test Buttons
                    VStack {
                        
                        // The guiding text that the tester should say for the speaking test.
                        Text("Say “Basic, Explicit, Irregardless.”")
                            .font(.system(size: 40, weight: .bold, design: .default))
                            .foregroundColor(Color.white)
                            .opacity(guidingTextOpacity)
                            .basicEaseIn(delayCount: 0.6) { 
                                guidingTextOpacity = 1.0
                            }
                        
                        // Record Button
                        Button{
                            // Check the AudioRecorder status.
                            if self.audioRecorder.recording == false {
                                self.audioRecorder.startRecording()
                                navigationButtonIsActive = false
                            } else {
                                self.audioRecorder.stopRecording()
                                navigationButtonIsActive = true
                                print("Audio file: \(audioRecorder.audioFileName!)")
                            }
                        } label: {
                            Image(systemName: audioRecorder.recording ? "mic.fill" : "mic")
                                .font(.system(size: 100, weight: .medium, design: .default))
                                .padding(40)
                        }
                        .foregroundColor(Color.white)
                        .opacity(recordButtonOpacity)
                        .basicEaseIn(delayCount: 0.7) { 
                            recordButtonOpacity = 1.0
                        }
                        
                        // Info text that helps to how to use the record button.
                        Text(
                            audioRecorder.recording ? "Tap \(Image(systemName: "mic.fill")) to stop recording." :
                                "Tap \(Image(systemName: "mic")) to start recording.")
                            .font(.system(size: 17, weight: .regular, design: .default))
                            .foregroundColor(Color.secondary)
                            .opacity(infoTextOpacity)
                            .basicEaseIn(delayCount: 0.8) { 
                                infoTextOpacity = 1.0
                            }
                    }
                }
                .frame(width: 900, height: 600)
                .clipped()
                .background(Color(.systemGray5))
                .cornerRadius(47)
                .opacity(backgroundOpacity)
                .basicEaseIn(delayCount: 0) { 
                    backgroundOpacity = 1.0
                }
                
                Spacer()
                
                // Navigation Button
                HStack(alignment: .bottom, spacing: 0) {
                    Spacer()
                    Button("Next") { 
                        // Showing Progress View
                        showProgressView = true
                        
                        // Calling AuidoClassificationProvider after 0.01 min later.
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){
                            AudioClassificationProvider().predictionResult(audioFileUrl: audioRecorder.audioFileName)
                            
                            withAnimation { 
                                nextPage = true
                            }
                        }
                    }
                    .buttonStyle(NavigationButtonStyle(color: Color(.systemGray5)))
                    .disabled(
                        navigationButtonIsActive ? false : true
                    )
                }
                .padding(.leading, 20)
                .padding(.bottom, 20)
                .opacity(navigationButtonIsActive ? navigationButtonOpacity : 0.5)
                .basicEaseIn(delayCount: 1) { 
                    navigationButtonOpacity = 1.0
                }
            }
            .zIndex(1.0)
            
            // Custom Progress View
            PAIProgressView()
                .zIndex(2.0)
                .opacity(showProgressView ? 1.0 : 0.0)
        }
        
        .navigationStack()
        .overlay(nextPage ? HandwritingTestScene() : nil)
    }
    
}
