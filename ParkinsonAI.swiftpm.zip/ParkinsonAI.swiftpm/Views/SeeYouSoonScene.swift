import SwiftUI

struct SeeYouSoonScene: View {
    
    // MARK: Properties
    
    // Controlling the page navigation.
    @State var nextPage: Bool = false
    
    // MARK: Animation Properties
    @State var backgroundOpacity = 0.0
    @State var imageOpacity = 0.0
    @State var copyrightTextOpacity = 0.0
    @State var navigationButtonOpacity = 0.0
    
    // MARK: View
    
    var body: some View {
        VStack {
            
            Spacer()
            
            // The informational text which is appears on the top of the screen.
            InfoTextView(subtitle: " WWDC22", subtitleColor: .blue, title: "Charming! Isn't it?", titleSize: 50, bodyIsOn: true, bodyText: "You have completed the test. Now, you know what Parkinson's is and you have seen how useful machine learning can be to people in the future. Thank you for being with me on this journey.", bodyTextColor: .secondary, bodyTextSize: 20, bodyPaddingTop: 20, bodyWidth: 800)
            
            VStack(spacing: 25) {
                
                // "SeeYouSoonMemojies" Image
                Image("SeeYouSoonMemojies", bundle: nil)
                    .renderingMode(.original)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 670, alignment: .center)
                    .clipped()
                    .opacity(imageOpacity)
                    .basicEaseIn(delayCount: 0.6) { 
                        imageOpacity = 1.0
                    }
                
                // Copyright Text
                Text("Made with ❤️ by  Ataberk Turan")
                    .font(.system(size: 20, weight: .medium, design: .default))
                    .foregroundColor(Color.white)
                    .opacity(copyrightTextOpacity)
                    .basicEaseIn(delayCount: 0.8) { 
                        copyrightTextOpacity = 1.0
                    }
            }
            .padding(.top, 30)
            .opacity(backgroundOpacity)
            .basicEaseIn(delayCount: 0) { 
                backgroundOpacity = 1.0
            }
            
            Spacer()
            
            // Navigation Button
            HStack(alignment: .bottom, spacing: 0) {
                Spacer()
                Button("Restart") { 
                    withAnimation { 
                        nextPage = true
                    }
                }
                .buttonStyle(NavigationButtonStyle(color: .red))
            }
            .padding(.leading, 20)
            .padding(.bottom, 20)
            .opacity(navigationButtonOpacity)
            .basicEaseIn(delayCount: 1) { 
                navigationButtonOpacity = 1.0
            }
        }
        .navigationStack()
        .overlay(nextPage ? WelcomeScene() : nil)
    }
    
}
