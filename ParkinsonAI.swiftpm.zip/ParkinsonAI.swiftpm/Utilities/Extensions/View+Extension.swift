import SwiftUI

// MARK: View Extensions

// Custom Navigation View Properties
extension View {
    func navigationStack() -> some View {
        self
            .background(Color.black)
            .edgesIgnoringSafeArea(.all)
            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
    }
}

// Reusable Custom "easeIn" Animation
public extension View {
    func basicEaseIn(using animation: Animation = Animation.easeIn(duration: 1), delayCount: Double, _ action: @escaping () -> Void) -> some View {
        let delay = animation.delay(delayCount)
        
        // Setting the animation action.
        return onAppear {
            withAnimation(delay) {
                action()
            }
        }
    }
    
}
