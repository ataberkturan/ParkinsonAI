import SwiftUI

class OverallScoreCalculator: ObservableObject {
    
    // MARK: Properties
    
    // View Model
    static var shared = OverallScoreCalculator()
    
    @Published var requiredQuestionAnswer = Bool()
    @Published var handTremorTestResult = Int()
    @Published var speakingTestResult = Int()
    @Published var handwritingTestResult = Int()
    
    // MARK: Functions
    
    func calculate() -> Int {
    
        // Properties
        var handTremorResultPercentage = Int()
        var speakingResultPercantage = Int()
        var handwritingTestPercantage = Int()
        
        // Calculating overall score based on required question's answer.
        if requiredQuestionAnswer {
            handTremorResultPercentage = getPercantage(value: handTremorTestResult, percentage: 30)
            speakingResultPercantage = getPercantage(value: speakingTestResult, percentage: 50)
            handwritingTestPercantage = getPercantage(value: handwritingTestResult, percentage: 20)
        } else {
            handTremorResultPercentage = getPercantage(value: handTremorTestResult, percentage: 50)
            speakingResultPercantage = getPercantage(value: speakingTestResult, percentage: 30)
            handwritingTestPercantage = getPercantage(value: handwritingTestResult, percentage: 20)
        }
        
        // Returning the final result.
        return handTremorResultPercentage + speakingResultPercantage + handwritingTestPercantage
    }
    
    func getPercantage(value: Int, percentage: Int) -> Int {
        return value * percentage/100
    }
    
}
