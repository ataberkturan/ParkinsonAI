import SwiftUI
import PencilKit

// To capture drawing for PAIHandwiritingML model.
struct DrawingPad : UIViewRepresentable {
    
    // MARK: Properties
    
    @Binding var canvas : PKCanvasView
    @Binding var type : PKInkingTool.InkType
    @Binding var color : Color
    
    var ink : PKInkingTool{
        PKInkingTool(type, color: UIColor(color))
    }
    
    // MARK: Functions
    
    func makeUIView(context: Context) -> PKCanvasView {
        canvas.drawingPolicy = .anyInput
        canvas.tool = ink 
        canvas.backgroundColor = .tertiaryLabel
        
        return canvas
    }
    
    func updateUIView(_ uiView: PKCanvasView, context: Context) {
        // No need to update anything.
    }
}
